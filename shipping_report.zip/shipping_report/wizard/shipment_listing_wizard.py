from odoo import models, fields


class ShipmentListingWizard(models.TransientModel):
    _name = "shipment.listing.wizard"
    _description = "Shipment Listing Wizard"

    client_id = fields.Many2one(
        "res.partner",
        string="Client",
        domain=[("customer_rank", ">", 0), ("is_company", "=", True)]
    )

    is_consignor = fields.Boolean(string="Client as Consignor", default=True)
    is_consignee = fields.Boolean(string="Client as Consignee", default=True)
    is_billing_client = fields.Boolean(string="Client as Billing", default=True)

    freight_direction = fields.Selection(
        [
            ("all", "All"),
            ("import", "Import"),
            ("export", "Export"),
        ],
        string="Freight Direction",
        default="all",
    )

    shipment_transport = fields.Selection(
        [
            ("air", "Air"),
            ("sea", "Sea"),
            ("road", "Road"),
        ],
        string="Transport",
    )

    def action_preview(self):
        self.ensure_one()
        return self.env.ref(
            "shipping_report.action_shipment_listing_preview"
        ).report_action(self)

    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref(
            "shipping_report.shipment_listing_pdf"
        ).report_action(self)

    def action_print_xlsx(self):
        self.ensure_one()
        return self.env.ref(
            "shipping_report.shipment_listing_xlsx"
        ).report_action(self)


    def _get_shipments(self):
        domain = []

        if self.client_id and not (
            self.is_consignor or self.is_consignee or self.is_billing_client
        ):
            self.is_consignor = True
            self.is_consignee = True
            self.is_billing_client = True

        if self.client_id:
            client_domain = []

            if self.is_consignor:
                client_domain.append(("hbl_consigner_id", "=", self.client_id.id))

            if self.is_consignee:
                client_domain.append(("hbl_consignee_id", "=", self.client_id.id))

            if self.is_billing_client:
                client_domain.append(("hbl_customer_id", "=", self.client_id.id))

            if client_domain:
                domain += ["|"] * (len(client_domain) - 1)
                domain += client_domain

        if self.shipment_transport == "sea":
            domain.append(("mode_id.name", "ilike", "Sea"))

        elif self.shipment_transport == "air":
            domain.append(("mode_id.name", "ilike", "Air"))

        elif self.shipment_transport == "road":
            domain.append(("mode_id.name", "ilike", "Road"))

        if self.freight_direction != "all":
            domain.append(("mode_id.code", "=", self.freight_direction))

        return self.env["ship.shipment"].search(
            domain,
            order="hbl_depdate desc"
        )