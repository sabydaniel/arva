from odoo import models, fields, api
from datetime import timedelta
import base64

class WeeklyMailScheduler(models.Model):
    _name = "weekly.mail.scheduler"
    _description = "Weekly Mail Scheduler"

    @api.model
    def send_weekly_report(self):

        today = fields.Date.today()

        week_end = today - timedelta(days=today.weekday() + 1)
        week_start = week_end - timedelta(days=6)

        recipients = self.env['ir.config_parameter'].sudo().get_param(
            'weekly_auto_mail.recipients'
        )

        log = self.env['weekly.mail.log'].create({
            'week_start': week_start,
            'week_end': week_end,
            'recipients': recipients,
        })

        try:
            records = self.env['ship.shipment'].search([
                ('invoice_status', '=', 'to invoice'),
            ])

            report = self.env.ref('shipping_report.unbilled_jobs_xlsx')

            xlsx_content, _ = report._render_xlsx(records.ids)

            attachment = self.env['ir.attachment'].create({
                'name': f"Unbilled_{week_start}_{week_end}.xlsx",
                'type': 'binary',
                'datas': base64.b64encode(xlsx_content),
                'mimetype':
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            })

            log.attachment_id = attachment.id

            template = self.env.ref('weekly_auto_mail.weekly_mail_template')

            template.send_mail(
                log.id,
                email_values={
                    'email_to': recipients,
                    'attachment_ids': [(4, attachment.id)],
                },
                force_send=True
            )

            log.state = 'sent'

        except Exception as e:
            log.state = 'failed'
            log.error_message = str(e)