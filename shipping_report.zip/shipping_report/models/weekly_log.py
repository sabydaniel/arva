from odoo import models, fields

class WeeklyMailLog(models.Model):
    _name = "weekly.mail.log"
    _description = "Weekly Mail Log"

    week_start = fields.Date()
    week_end = fields.Date()
    recipients = fields.Char()
    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('failed', 'Failed')
    ], default='draft')
    error_message = fields.Text()